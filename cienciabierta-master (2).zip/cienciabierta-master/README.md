# cienciabierta
Este trabajo fue realizado durante el año 2019 para el curso de "Estadística multivariada". La autoría del análisis corresponde a Carolina Astudillo, Mailen Kimelman y Javiera Urrutia. 
Se ha trabajado en la reproducción de los resultados del documento para democratizar el acceso al conocimiento. 
El trabajo de reproducción de esta investigación ha sido hecha por Carolina Astudillo, Paula Larenas, Javiera Urrutia y Francisca Vergara. 
La estructura de las carpetas está hecha en base al protocolo IPO. 
